import UIKit
//
//Класи: Кіт, собака, папуга, півень, корова
//Функції: voice, fly
//Атрибути: name, feetCount, wingsCount,
//Зовнішні функції: getMilk, getEgg

class Animal {
    var sound: String { "" }
    var name: String = ""
    var feetCount: UInt { 0 }
    open func voice() {
        print("Hi! I am a \(String(describing: Self.self)) I say: \(sound.self)")
    }
}

class FourFootedAnimal: Animal {
    override var feetCount: UInt { 4 }
}

class MilkGivingAnimal: FourFootedAnimal {
    var milkLitresCounter : UInt = 0
    public func getMilk () -> UInt {
        if milkLitresCounter > 0 {
            milkLitresCounter -= 1
            return 1
        }
        else {
            print("Not enough milk!")
            return 0
        }
    }
}

class Bird: Animal{
    override var feetCount: UInt { 2 }
    var startMetres = 0
    let wingsCount = 2
    open func fly (){
        self.startMetres += Int.random(in: 1..<100)
        print("Hi! I have already flight  \(self.startMetres) metres!")
    }
}

class EggGivingAnimal: Bird {
    
    var eggsCounter : UInt = 0
    
    public func getEggs (numberOfRequestedEggs: UInt) -> UInt {
        print("I have \(eggsCounter) eggs. You asked for \(numberOfRequestedEggs) !")
        
        if  eggsCounter > 0 {
            if numberOfRequestedEggs > eggsCounter{
                print("Sorry,I don't have enough eggs!")
                return 0
            }
            
            eggsCounter -= numberOfRequestedEggs
            print("You are welcome! \(eggsCounter) are left.")
            return numberOfRequestedEggs
        }
        
        print("I don't have eggs!")
        return 0
    }
}


class Cat: FourFootedAnimal{
    override var sound: String {"'Meow!'"}
}

class Dog: FourFootedAnimal{
    override var sound: String {"'Bow-Wow!'"}
}

class Parrot: Bird{
    override var sound: String {"'Tweeety!'"}
}

class Cock: Bird{
    override var sound: String {"'Cock-a-doodle-do!'"}
}

class Cow: MilkGivingAnimal{
    override var sound: String {"'MoooU!'"}
}

//Відпрацюванняя:
//--  --  --  --  -- -- -- -- -- -- --  --  --  --  --  --  --  --  --  --
let kitty = Cat()
kitty.voice()

var aligator = Animal()
aligator.voice()

var buronka = Cow()
buronka.milkLitresCounter = 0
buronka.getMilk()
buronka.milkLitresCounter

var kyrka = EggGivingAnimal()
kyrka.eggsCounter = 120
let eggsResult = kyrka.getEggs(numberOfRequestedEggs: 10)
let eggsResult1 = kyrka.getEggs(numberOfRequestedEggs: 110)
let eggsResult2 = kyrka.getEggs(numberOfRequestedEggs: 100)
kyrka.fly()



//------------------------------------------------------------------------------
//Класи: Баскетбол, футбол, теніс, пінг понг, волейбол, шахи, покер, фехтування
//Функції: 3+
//Атрибути: 5+
//Зовнішні функції: startGame(team: [Athlete], with: Equipment)
enum Equipment{
    case ball
    case racket
    case sword
    case card
}

class Athlete {
    var surname : String
    var team : String
    var age : UInt
    var proYears : UInt
    
    init(surname : String = "", age : UInt = 16, proYears : UInt = 3,team : String = ""){
        self.surname = surname
        self.age = age
        self.proYears = proYears
        self.team = team
    }
}

class Sport {
    var score : UInt = 0
    var position: String = "usual"
    
    open func scorePoint () -> UInt {
        self.score += 1
        
        return score
    }
    
    open func whoStarts(team: [Athlete], team2 : [Athlete] ) {
        var result = Int.random(in: 1...2)
        if result == 1 {
            print("\(team.first?.team ?? "ERROR") is the first to start!")
        }
        else {
            print("\(team.first?.team ?? "ERROR") is the first to start!")
        }
    }
    
    open func startGame (team: [Athlete], with equipment: Equipment) {
        switch equipment {
        case .ball, .card:
            print("\(team.first?.surname ?? "ERROR") starts a game!")
        case .sword:
            print("\(team.first?.surname ?? "ERROR") starts a fight!")
            
        default:
            print("\(team.first?.surname ?? "ERROR") starts a match!")
        }
        
    }
}

class IndividualSport: Sport{
}

class Tenis : IndividualSport{
    
}

class PingPong : IndividualSport{
    
}
class SportGames: Sport{
    
}

class TeamSport: SportGames{
    
}

class Basketball: TeamSport{
    override func scorePoint() -> UInt {
        switch position {
        case "usual":
            self.score += 2
            return score
        case "FIBA:6.75m", "NBA:7.24m":
            self.score += 3
            return score
        default:
            super.scorePoint()
        }
        return score
    }
}

class Football: TeamSport{
    
}

class VoleyBall:TeamSport{
    
}

class Fencing:IndividualSport{
    
}

class Сhess:IndividualSport{
    
}

class Poker:IndividualSport{
    
}


let basketballPlayer1 = Athlete ()
basketballPlayer1.surname = "Chekun"
basketballPlayer1.age = 28
basketballPlayer1.proYears = 10
basketballPlayer1.team = "BrooklynNets"

let basketballPlayer2 = Athlete ()
basketballPlayer2.surname = "Fedorchuk"
basketballPlayer2.age = 28
basketballPlayer2.team = "BrooklynNets"

let basketballPlayer3 = Athlete(surname: "Shamshun", age: 17, proYears: 2, team: "BrooklynNets")

var brooklynNet: [Athlete] = [basketballPlayer1, basketballPlayer2, basketballPlayer3]

let player1 = Athlete(surname: "Bukov", age: 23, proYears: 2,team: "ChicagoBulls")
let player2 = Athlete(surname: "Melnuk", age: 24, proYears: 2,team: "ChicagoBulls")
let player3 = Athlete(surname: "Bondar", age: 35, proYears: 10,team: "ChicagoBulls")
let player4 = Athlete(surname: "Potapova", age: 28, proYears: 8,team: "ChicagoBulls")
let player5 = Athlete(surname: "Kuzmichuk", age: 24, proYears: 4,team: "ChicagoBulls")

var schicagoBulls: [Athlete] = [player1, player2, player3, player4, player5]

let game1 = Basketball ()
game1.whoStarts(team: brooklynNet, team2: schicagoBulls)
game1.startGame(team: brooklynNet, with: .ball)

